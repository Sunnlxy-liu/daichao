class NetErrorModel {
  final int code;
  final String msg;

  NetErrorModel(this.code, this.msg);
}
